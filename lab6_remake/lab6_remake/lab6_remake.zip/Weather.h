#pragma once
enum Weather
{
	RAIN, SUNNY, SNOWY
};